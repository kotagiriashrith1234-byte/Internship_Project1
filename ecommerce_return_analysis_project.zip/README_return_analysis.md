
# E-commerce Return Rate Reduction Analysis

## Dataset findings
- Orders: 6,000
- Returns: 887
- Overall return rate: 14.78%
- Logistic Regression holdout ROC-AUC: 0.571
- Strongest observed channel return rate: Social Media (16.57%)
- Return reason most frequent: Size/Fit Issue (213 records)

## Files
- `return_analysis.py`: reproducible sklearn training and export script
- `return_rate_dashboard.html`: interactive Plotly dashboard, open in a browser (internet needed for Plotly CDN)
- `orders_returns_powerbi.csv`: order-level facts plus predicted return probabilities and risk scores
- `product_return_risk.csv`: product-level actual/predicted return metrics
- `high_risk_products.csv`: product-level risk bucket High (>60% predicted probability)
- `product_analysis.csv`, `state_analysis.csv`, `region_analysis.csv`, `channel_analysis.csv`, `return_reason_analysis.csv`: analysis tables for Power BI
- `model_metrics.json`: model evaluation metrics

## Model
Logistic Regression uses product, state, region, marketing channel, quantity, unit price, discount, sales amount and order date components. Return date and return reason are excluded to avoid target leakage. Stratified 80/20 test split, seed 42. `class_weight='balanced'` used due to class imbalance.

## Power BI suggestions
Import the CSV exports. Create slicers for order date, product, state, region and marketing channel. KPI cards: orders, returns, return rate, mean predicted risk. Visuals: return rate by product/channel/region, return reason count, product volume vs return rate. Add product_id drill-through page with orders, return reason and risk score.

## Caveats
Dataset has no explicit category or supplier attributes, so those analyses are not available without a product master mapping. Risk score is predictive, not causal; use the holdout metrics to judge quality. The CSV contains order-level predictions on the training dataset after final refit, so it is a scoring output rather than unbiased performance evaluation.
