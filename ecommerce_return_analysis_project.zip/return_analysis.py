
"""E-commerce return risk model and analysis exports.
Run: python return_analysis.py --input orders_returns.csv --output outputs
"""
import argparse, os, json
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, accuracy_score, precision_score, recall_score, f1_score

CATS=['product_id','state','region','marketing_channel']
NUMS=['quantity','unit_price','discount_pct','sales_amount','order_month','order_dayofweek','order_year']
FEATURES=CATS+NUMS

def prepare(df):
    df=df.copy()
    df['order_date']=pd.to_datetime(df['order_date'],errors='coerce')
    df['order_month']=df['order_date'].dt.month
    df['order_dayofweek']=df['order_date'].dt.dayofweek
    df['order_year']=df['order_date'].dt.year
    for c in CATS: df[c]=df[c].fillna('Unknown').astype(str).str.strip()
    for c in NUMS: df[c]=pd.to_numeric(df[c],errors='coerce')
    return df

def make_model():
    prep=ColumnTransformer([('categorical',OneHotEncoder(handle_unknown='ignore'),CATS),
                           ('numeric',StandardScaler(),NUMS)])
    return Pipeline([('preprocess',prep),('classifier',LogisticRegression(max_iter=1200,class_weight='balanced',random_state=42))])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',default='orders_returns.csv')
    ap.add_argument('--output',default='outputs')
    args=ap.parse_args()
    os.makedirs(args.output,exist_ok=True)
    raw=pd.read_csv(args.input)
    df=prepare(raw)
    X=df[FEATURES]; y=df['returned'].astype(int)
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
    model=make_model(); model.fit(Xtr,ytr)
    p=model.predict_proba(Xte)[:,1]; pred=(p>=.5).astype(int)
    metrics={'rows':len(df),'return_rate':float(y.mean()),'roc_auc':float(roc_auc_score(yte,p)),
             'accuracy':float(accuracy_score(yte,p)),'precision':float(precision_score(yte,p,zero_division=0)),
             'recall':float(recall_score(yte,p,zero_division=0)),'f1':float(f1_score(yte,p,zero_division=0))}
    with open(os.path.join(args.output,'model_metrics.json'),'w') as f: json.dump(metrics,f,indent=2)
    model.fit(X,y); df['predicted_return_probability']=model.predict_proba(X)[:,1]
    df['return_risk_score']=(df.predicted_return_probability*100).round(1)
    df.to_csv(os.path.join(args.output,'orders_returns_powerbi.csv'),index=False)
    product=df.groupby('product_id',as_index=False).agg(order_count=('order_id','count'),return_count=('returned','sum'),
        actual_return_rate=('returned','mean'),avg_predicted_return_probability=('predicted_return_probability','mean'),
        total_sales_amount=('sales_amount','sum'),avg_discount_pct=('discount_pct','mean'))
    product['return_risk_score']=(product.avg_predicted_return_probability*100).round(1)
    product['risk_level']=pd.cut(product.avg_predicted_return_probability,[-.001,.30,.60,1.001],labels=['Low','Medium','High']).astype(str)
    product.to_csv(os.path.join(args.output,'product_return_risk.csv'),index=False)
    product[product.risk_level=='High'].sort_values('return_risk_score',ascending=False).to_csv(os.path.join(args.output,'high_risk_products.csv'),index=False)
if __name__=='__main__': main()
